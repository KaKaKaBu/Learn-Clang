//
// Created by zhu on 2025/10/21.
//

#include <stdio.h>

double add(double a, double b);

double subtract(double a, double b);

double multiply(double a, double b);

double divide(double a, double b);

void displayMenu();

void clearInputBuffer();

double getNumberInput();

int main() {
    int choice;
    double num1, num2, result;

    printf("=== �򵥼����� ===\n");

    while (1) {
        displayMenu();
        printf("��ѡ����� (1-5): ");

        if (scanf("%d", &choice) != 1) {
            printf("������Ч�����������֣�\n");
            clearInputBuffer();
            continue;
        }

        switch (choice) {
            case 1:
                num1 = getNumberInput();
                num2 = getNumberInput();
                result = add(num1, num2);
                printf("���: %.2lf + %.2lf = %.2lf\n\n", num1, num2, result);
                break;

            case 2:
                num1 = getNumberInput();
                num2 = getNumberInput();
                result = subtract(num1, num2);
                printf("���: %.2lf - %.2lf = %.2lf\n\n", num1, num2, result);
                break;

            case 3:
                num1 = getNumberInput();
                num2 = getNumberInput();
                result = multiply(num1, num2);
                printf("���: %.2lf �� %.2lf = %.2lf\n\n", num1, num2, result);
                break;

            case 4:
                num1 = getNumberInput();
                num2 = getNumberInput();
                if (num2 == 0) {
                    printf("���󣺳�������Ϊ�㣡\n\n");
                } else {
                    result = divide(num1, num2);
                    printf("���: %.2lf �� %.2lf = %.2lf\n\n", num1, num2, result);
                }
                break;

            case 5:
                printf("��лʹ�ü��������ټ���\n");
                return 0;

            default:
                printf("��Ч��ѡ��\n\n");
                break;
        }
    }

    return 0;
}

double add(double a, double b) {
    return a + b;
}

double subtract(double a, double b) {
    return a - b;
}

double multiply(double a, double b) {
    return a * b;
}

double divide(double a, double b) {
    return a / b;
}

void displayMenu() {
    printf("\n");
    printf("1. �ӷ� (+)\n");
    printf("2. ���� (-)\n");
    printf("3. �˷� (��)\n");
    printf("4. ���� (��)\n");
    printf("5. �˳�\n");
    printf("--------------------------------\n");
}

void clearInputBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

double getNumberInput() {
    double number;
    printf("����������: ");
    while (scanf("%lf", &number) != 1) {
        printf("������Ч������������: ");
        clearInputBuffer();
    }
    return number;
}
